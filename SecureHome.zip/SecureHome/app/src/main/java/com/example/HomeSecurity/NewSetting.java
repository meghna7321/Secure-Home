package com.example.HomeSecurity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class NewSetting extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_setting);
    }
}